package com.angrybirds.game.Screen;

import com.angrybirds.game.Main;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;
import java.util.Random;

public class OptionsScreen implements Screen {

    private Main game;
    private OrthographicCamera gamecam;
    private Viewport gameport;
    private Texture backgroundTexture;
    private Stage stage;
    private TextButton PlayButton, FeedbackButton, MusicButton, backButton;
    private Music theme;
    private BitmapFont font; // Store the font
    private Texture buttonTexture, pressTexture; // Store the button texture

    public OptionsScreen(Main game, BitmapFont font, Texture buttonTexture, Texture pressTexture, Music theme, OrthographicCamera gamecam, Viewport gameport, TextButton.TextButtonStyle buttStyle) {
        this.game = game;
        this.font = font; // Assign the passed font
        this.buttonTexture = buttonTexture;
        this.pressTexture = pressTexture;
        ArrayList<Texture> bgs = new ArrayList<Texture>();
        bgs.add(game.assetManager.get("bg1.jpg", Texture.class));
        bgs.add(game.assetManager.get("bg2.jpg", Texture.class));
        bgs.add(game.assetManager.get("bg3.jpg", Texture.class));
        bgs.add(game.assetManager.get("bg4.jpg", Texture.class));
        Random rand = new Random();
        backgroundTexture = bgs.get(rand.nextInt(bgs.size()));
        this.theme = theme;
        this.gamecam = gamecam;
        this.gameport = gameport;

        stage = new Stage(gameport);

        backButton = new TextButton("", buttStyle);
        backButton.setSize(120, 120);
        backButton.setPosition((gameport.getWorldWidth()) - 150, (gameport.getWorldHeight()) - 150);
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new MainScreen(game));  // Go back to MainScreen
            }
        });
        stage.addActor(backButton);

        // Create button styles using the passed font and button texture
        TextButton.TextButtonStyle buttonStyle = new TextButton.TextButtonStyle();
        buttonStyle.up = new TextureRegionDrawable(buttonTexture);
        buttonStyle.down = new TextureRegionDrawable(pressTexture);
        buttonStyle.font = font;
        buttonStyle.fontColor = Color.BLACK;

        // Create the buttons
        PlayButton = new TextButton("Play", buttonStyle);
        FeedbackButton = new TextButton("FAQ", buttonStyle);
        MusicButton = new TextButton("Music", buttonStyle);
//        Exitbutton = new TextButton("Exit", buttonStyle);


        // Set button sizes and positions
        PlayButton.setSize(500, 150);
        FeedbackButton.setSize(100, 80);
        MusicButton.setSize(150, 80);
//        Exitbutton.setSize(120, 80);


        PlayButton.setPosition((gameport.getWorldWidth() - PlayButton.getWidth()) / 2, (gameport.getWorldHeight() / 2 )-200);
        FeedbackButton.setPosition(gameport.getWorldWidth() -130, 30);
        MusicButton.setPosition(30 , gameport.getWorldHeight() - 110);
//        Exitbutton.setPosition(((gameport.getWorldWidth() - Exitbutton.getWidth()) / 2 ), (gameport.getWorldHeight() / 2) - 140);

        // Add button click listeners
        PlayButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                System.out.println("Play button clicked in Options Screen!");
            }
        });

        FeedbackButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                System.out.println("Feedback button clicked in Options Screen!");
            }
        });

        MusicButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                System.out.println("Music button clicked in Options Screen!");
                if (theme.isPlaying()){
                    theme.pause();
                }
                else{
                    theme.play();
                }
            }
        });



        // Add elements to the stage
        stage.addActor(PlayButton);
        stage.addActor(FeedbackButton);
        stage.addActor(MusicButton);
//        stage.addActor(Exitbutton);

        // Set input processor to handle button clicks
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void show() {
        if (!theme.isPlaying()) {
            theme.setLooping(true);
            theme.play();
        }
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Draw the background
        game.batch.setProjectionMatrix(gamecam.combined);
        game.batch.begin();
        game.batch.draw(backgroundTexture, 0, 0, gameport.getWorldWidth(), gameport.getWorldHeight());
        game.batch.end();

        // Draw UI elements
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        gameport.update(width, height);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {
        dispose();
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
