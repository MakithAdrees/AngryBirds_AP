package com.angrybirds.game.Extras;

import com.angrybirds.game.Blocks.Block;
import com.badlogic.gdx.graphics.Texture;

import java.util.ArrayList;

public class TNT {
    public ArrayList<Block> BlocksAround_List;
    private float Damage_TNT;
    private Texture TNT_Model, Boom_Image;

    public void Explosion(){
        return;}
}
