package com.angrybirds.game.Blocks;

public class Dimension {
    protected float Block_Width, Block_Height;

    public Dimension(float Block_Width, float Block_Height){
        this.Block_Height = Block_Height;
        this.Block_Width = Block_Width;
    }
    //Getters and Setters
}
