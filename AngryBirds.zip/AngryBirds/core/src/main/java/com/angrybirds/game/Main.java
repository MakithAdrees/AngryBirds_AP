package com.angrybirds.game;

import com.angrybirds.game.Screen.LoadingScreen;
import com.angrybirds.game.Screen.MainScreen;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Music;

public class Main extends Game {
    public SpriteBatch batch;
    public AssetManager assetManager;

    @Override
    public void create(){
        batch = new SpriteBatch();
        assetManager = new AssetManager();

        // Preload assets
        assetManager.load("bg1.jpg", Texture.class);
        assetManager.load("bg2.jpg", Texture.class);
        assetManager.load("bg3.jpg", Texture.class);
        assetManager.load("bg4.jpg", Texture.class);
        assetManager.load("background.jpg", Texture.class);
        assetManager.load("angrybirdsbg.jpg", Texture.class);
        assetManager.load("loadingimage.jpg", Texture.class);
        assetManager.load("login.png", Texture.class);
        assetManager.load("signup.png", Texture.class);
        assetManager.load("bad.mp3", Music.class);
        assetManager.load("theme_song_for_game.mp3", Music.class);
        assetManager.load("button.png", Texture.class);
        assetManager.load("button_rectangle_flat.png", Texture.class);
        assetManager.load("button_rectangle_gloss.png", Texture.class);
        assetManager.load("check_square_color_cross.png", Texture.class);
        assetManager.load("font/font2.fnt", BitmapFont.class);
//        assetManager.load("ang.tff", BitmapFont.class);
        assetManager.load("font/w_0.png", Texture.class);
        assetManager.load("font/w_1.png", Texture.class);
        assetManager.finishLoading();

        setScreen(new LoadingScreen(this));

    }
    @Override
    public void render(){
        super.render();
    }
    @Override
    public void dispose() {
    }
}
