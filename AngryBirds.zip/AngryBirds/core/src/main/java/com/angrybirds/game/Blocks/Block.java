package com.angrybirds.game.Blocks;

import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;

abstract public class Block {
    protected String Material_Name;
    public float Hp;
    private Texture Block_Texture;
    private Music Breaking_Sound;
    protected Dimension dimension;
    // Constructor

//    public Block(String Material_Name, float Hp, Texture Block_Texture, Sound Breaking_Sound){
//        this.Material_Name = Material_Name;
//        this.Hp = Hp;
//        this.Block_Texture = Block_Texture;
//        this.Breaking_Sound = Breaking_Sound

}
    // Getter Setters
   // will be implimented later
