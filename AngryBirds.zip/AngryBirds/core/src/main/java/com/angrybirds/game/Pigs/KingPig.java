package com.angrybirds.game.Pigs;

import com.badlogic.gdx.graphics.Texture;

public class KingPig extends Pig {
    private Texture Healthy;
    public void KingDead() {
        return;
    }

    public void Change_Pig_Image(Pig pig) {
        return;
    }
}
