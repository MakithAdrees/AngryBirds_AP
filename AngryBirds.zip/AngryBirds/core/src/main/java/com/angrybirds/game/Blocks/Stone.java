package com.angrybirds.game.Blocks;

import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;

public class Stone extends Block {


    public Stone() {
        this.Material_Name = "Stone";
        this.Hp = Hp;
//        this.Block_Texture = new Texture("Stone.png");
//        this.Breaking_Sound = Gdx.audio.newMusic(Gdx.files.internal("block_breaking.mp3"));
    }
}