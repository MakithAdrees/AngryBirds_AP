package com.angrybirds.game.Extras;

import com.angrybirds.game.Birds.Bird;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;

public class Catapult {
    public float Velocity;
    private Texture CatapultModel;
    private Music CatapultSound;

    public void Bird_menu() {
        return;}

    public void Bird_Launch(Bird bird){
        return;}

    public void Aim(){
        return;}
}
