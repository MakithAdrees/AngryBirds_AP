package com.angrybirds.game.Pigs;

import com.badlogic.gdx.graphics.Texture;

public class HelmetPig extends Pig {
    private Texture Healthy, Hurt;
    public void PigRIP() {
        return;
    }

    public void Change_Pig_Image(Pig pig) {
        return;
    }
}
