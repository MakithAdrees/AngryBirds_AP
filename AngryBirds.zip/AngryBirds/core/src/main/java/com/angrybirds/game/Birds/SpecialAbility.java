package com.angrybirds.game.Birds;

public interface SpecialAbility {
    public void SpecialAbility();
}
