package com.angrybirds.game.Blocks;

import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;

public class Wood extends Block {

    public Wood() {
        this.Material_Name = "Wood";
        this.Hp = Hp;
//        this.Block_Texture = new Texture("Wood.png");
//        this.Breaking_Sound = Gdx.audio.newMusic(Gdx.files.internal("block_breaking.mp3"));
    }
}